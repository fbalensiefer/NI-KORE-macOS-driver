# KORE 1 v0.23 — PCM framing audit (diagnostic)

**No working audio playback is claimed.** This is a controlled audit of the v0.22 silence packet model. MIDI behavior is inherited from v0.22.

## Run (Apple Silicon macOS)

```sh
brew install libusb pkg-config
./build.sh
python3 framing_audit.py
python3 framing_autotest.py
```

The offline script validates the **existing hypothesis**: 176-byte packet, two paired streams, alignment=2, 8-byte stride; candidate checkbytes at offsets 4 and 5 in each block. It outputs `framing_audit.json` with positions, first 32 bytes, and SHA256. These assumptions are **not** a byte-for-byte verification against the current upstream Linux `snd-usb-caiaq` driver. Do not infer channel routing or headphone DAC mapping from these offsets.

The optional hardware A/B runs ZERO / LINUX / LINUX / ZERO, 5 seconds each, same fixed packet length and independent transfer scheduling, no tone. Record whine and upload `KORE-v0.23-results.zip`.

**Safety:** start with headphones off ears, minimum volume, abort on discomfort. USB ACK and successful transfers do not establish actual PCM decoding. The KORE audio device spec (analog in/out and paired streams) is logged, but mapping of 4 outputs to headphone L/R is unverified. No CoreAudio HAL driver is included.

**Next:** independently compare exact upstream `sound/usb/caiaq/audio.c` framing and KORE-specific output routing before any new PCM playback experiment.
