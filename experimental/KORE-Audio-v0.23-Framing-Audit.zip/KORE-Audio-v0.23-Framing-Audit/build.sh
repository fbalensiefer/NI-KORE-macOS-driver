#!/bin/sh
set -eu
cd "$(dirname "$0")"
cc -std=c11 -Wall -Wextra -O2 -o kore-midi-audio-v0.23 kore-midi-audio-v0.23.c $(pkg-config --cflags --libs libusb-1.0) -framework CoreMIDI -framework CoreFoundation -lpthread -lm
printf 'Built kore-midi-audio-v0.23\n'
