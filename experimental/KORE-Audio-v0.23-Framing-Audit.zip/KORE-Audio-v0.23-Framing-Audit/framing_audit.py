#!/usr/bin/env python3
"""Offline audit of the current hypothesis, not proof of the Linux kernel protocol."""
import json, pathlib, hashlib
root=pathlib.Path(__file__).resolve().parent

def frame(mode, n=176, streams=2):
    b=bytearray(n); stride=streams*4
    for base in range(0,n,stride):
        for stream in range(streams):
            i=base+streams*2+stream
            if i>=n: continue
            check=((stream<<1) | (~(i//stride)&1)) & 255
            if mode=='zero':check=0
            b[i]=check
    return bytes(b)

report={'note':'Offline framing model copied from v0.22 caiaq_fill_silence. Stream/channel mapping and true Linux implementation NOT independently verified.', 'packet_bytes':176,'streams_assumed':2,'alignment_assumed':2,'stride_bytes':8,'blocks':22,'modes':{}}
for mode in ('zero','linux'):
    b=frame(mode)
    report['modes'][mode]={'sha256':hashlib.sha256(b).hexdigest(),'first_32_hex':b[:32].hex(' '),'nonzero_positions':[i for i,v in enumerate(b) if v], 'nonzero_count':sum(x!=0 for x in b)}
assert frame('zero')==bytes(176)
assert frame('linux')[:16]==bytes.fromhex('00 00 00 00 01 03 00 00 00 00 00 00 00 02 00 00')
(root/'framing_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='modes'},indent=2))
for mode,details in report['modes'].items():print(mode,details['first_32_hex'],'nonzero:',details['nonzero_count'])
print('PASS: model invariants; NOT hardware/driver validation')
