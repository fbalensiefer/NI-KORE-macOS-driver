#!/usr/bin/env python3
"""v0.23 controlled A/B, no tones; logs hardware-reported device spec and USB framing."""
from pathlib import Path
import subprocess, signal, re, json, zipfile, time, sys
p=Path(__file__).resolve().parent
exe=p/'kore-midi-audio-v0.23'
if not exe.exists():sys.exit('Run ./build.sh first')
subprocess.run([sys.executable,str(p/'framing_audit.py')],check=True)
print('v0.23: compare fixed 176-byte ZERO vs Linux-hypothesis checkbytes. NO PCM TONE.')
print('Headphones off ears, volume minimum; stop immediately if uncomfortable.')
if input('Type TEST: ').strip()!='TEST':sys.exit('Cancelled')
order=['zero','linux','linux','zero']
common=['--audio-duplex-silence','--audio-linux-urbs','--audio-linux-trace','--audio-hex-probe','--audio-report-ms','1000','--audio-out-fixed','--audio-tx-independent','--audio-startup-trace']
rows=[]
for i,mode in enumerate(order,1):
    print(f'\n{i}/4: {mode}, 5 seconds, fixed 176-byte packets')
    cmd=input('RUN / SKIP / QUIT: ').strip().upper()
    if cmd=='QUIT':break
    if cmd!='RUN':rows.append({'run':i,'mode':mode,'skipped':True});continue
    logfile=p/f'{i:02d}_{mode}.log'
    with logfile.open('w') as f:
        proc=subprocess.Popen([str(exe),*common,'--audio-checkbyte-pattern',mode],stdout=f,stderr=subprocess.STDOUT)
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.send_signal(signal.SIGINT)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
    data=logfile.read_text(errors='replace')
    def last(rx):
        m=re.findall(rx,data);return int(m[-1]) if m else None
    first=re.findall(r'AUDIO HEX OUT #1 len=(\d+):([^\n]+)',data)
    row={'run':i,'mode':mode,'heard':input('Whine? yes/no/uncertain: ').strip().lower(),
         'notes':input('Notes: ').strip(),'ack':'AUDIO init ACCEPTED' in data,
         'exit_code':proc.returncode,'out_packets':last(r'AUDIO OUT packets=(\d+)'),
         'out_errors':last(r'AUDIO OUT packets=\d+ bytes=\d+ errors=(\d+)'),
         'first_out_hex':first[0][1].strip() if first else None,
         'device_spec':next((line for line in data.splitlines() if 'AUDIO device spec:' in line),None),
         'log':logfile.name}
    rows.append(row);print(json.dumps(row,indent=2));time.sleep(2)
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
(p/'SUMMARY.md').write_text('# v0.23 framing audit\n\nA/B control, not proof of valid PCM framing. No test tone.\n\n```json\n'+json.dumps(rows,indent=2)+'\n```\n')
with zipfile.ZipFile(p/'KORE-v0.23-results.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in [p/'results.json',p/'SUMMARY.md',p/'framing_audit.json',*sorted(p.glob('[0-9][0-9]_*.log'))]:
        if f.exists():z.write(f,f.name)
print('Upload:',p/'KORE-v0.23-results.zip')
